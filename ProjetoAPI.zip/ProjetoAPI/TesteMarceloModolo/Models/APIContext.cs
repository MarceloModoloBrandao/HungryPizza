﻿using Microsoft.EntityFrameworkCore;

namespace TesteMarceloModolo.Models
{
    public class APIContext : DbContext
    {
        public APIContext(DbContextOptions<APIContext> options)
          : base(options)
        { }

        public DbSet<PedidoModel> Pedido { get; set; }
        public DbSet<ClienteModel> Cliente { get; set; }
        
    }
}
