﻿using System;
using System.Collections.Generic;


namespace TesteMarceloModolo.Models
{


    public class PedidoModel
    {
        public string ID { get; set; }
        public ClienteModel Cliente { get; set; }
        public List<PizzaModel> Pizzas { get; set; }
        public double Valor { get; set; }
        public double Frete { get; set; }

        public PedidoModel(ClienteModel _cliente, List<PizzaModel> _pizzas, double _valor, double _frete)
        {
            this.ID = new Guid().ToString();
            this.Cliente = _cliente;
            this.Pizzas = _pizzas;
            this.Valor = _valor;
            this.Frete = _frete;
        }

    }
}