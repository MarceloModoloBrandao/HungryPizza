﻿using System;
using System.Collections.Generic;


namespace TesteMarceloModolo.Models
{
    public class PizzaModel
    {
        public string ID { get; set; }
        public List<Sabor> Sabores { get; set; }
        public double Preco { get; set; }


        public PizzaModel(List<Sabor> _sabores, double _preco)
        {
            this.ID = Guid.NewGuid().ToString();
            Sabores = _sabores;
            Preco = _preco;
        }

    }

   

    public class Sabor
    {
        public string Descricao { get; set; }
        public double Valor { get; set; }

        public Sabor(string _pdescricao, double _pvalor)
        {
            this.Descricao = _pdescricao;
            this.Valor = _pvalor;
        }

    }
}
