﻿
namespace TesteMarceloModolo.Models
{
    public class ClienteModel
    {
        public long Fone { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }

        public ClienteModel(long _fone)
        {
            this.Fone = _fone;

        }

        public ClienteModel(long _fone, string _nome, string _endereco)
        {
            this.Fone = _fone;
            this.Nome = _nome;
            this.Endereco = _endereco;
        }
    }
}
