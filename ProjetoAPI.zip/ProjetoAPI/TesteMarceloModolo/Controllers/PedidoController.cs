﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TesteMarceloModolo.Models;


namespace TesteMarceloModolo.Controllers
{
    [System.Web.Http.Route("api/controller")]
    [ApiController]
    public class PedidoController : System.Web.Http.ApiController
    {
        private readonly APIContext _context;

        public PedidoController(APIContext context)
        {
            _context = context;
        }

        public PedidoController()
        {
            
        }




        [HttpPost]
        [Route("InserirPedido")]
        public System.Web.Http.IHttpActionResult InserirPedido([FromBody] PedidoModel pedido)
        {
            try
            {
                if (ValidarPedido(pedido))
                {
                    _context.Pedido.Add(pedido);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return Ok(pedido.ID);

        }

    

        [Route("RetornarPrecoPizza")]
        [HttpGet]
        public async Task<System.Web.Http.IHttpActionResult> RetornarPrecoPizza([FromBody] List<Sabor> Sabores)
        {
            double _preco = 0;
            double _total = 0;
            List<Sabor> _lista = null;
            

            try
            {
               
                if(Sabores.Count > 2)
                {
                    return Content(HttpStatusCode.BadRequest, new { erro = "Quantidade invalida" });
                }

                _lista = GetSabores();

                if (Sabores.Count == 1)
                {
                    foreach (Sabor _sabor in Sabores)
                    {
                        foreach (Sabor _sabor2 in _lista)
                        {
                            if (_sabor.Descricao == _sabor2.Descricao)
                            {
                                _preco = _sabor2.Valor;
                            }
                        }
                    }
                   
                }
                if (Sabores.Count == 2)
                {
                    foreach (Sabor _sabor in Sabores)
                    {
                        foreach (Sabor _sabor2 in _lista)
                        {
                            if (_sabor.Descricao == _sabor2.Descricao)
                            {
                                _total += _sabor2.Valor;
                            }
                        }
                    }
                    _preco = _total / Sabores.Count;
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { erro = "Erro ao RetornarPrecoPizza" } + ex.Message);
            }

            return Ok(_preco.ToString());
        }


        [Route("ListarPedidos/{fone}")]
        [HttpGet]
        public async Task<System.Web.Http.IHttpActionResult> ListarPedidos(long fone)
        {

            try
            {
                var _query = from opedido in _context.Pedido
                             where opedido.Cliente.Fone == fone
                             select new { Cliente = opedido.Cliente.Nome, Pizzas = opedido.Pizzas, Valor = opedido.Valor };
                return Ok(_query.ToList());

            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { erro = "Erro ao ListarPedidos" } + ex.Message);

            }

        }


        #region "Funcoes Privadas"

        private bool ValidarPedido(PedidoModel pedido)
        {

            try
            {
                if (!EhCliente(pedido.Cliente.Fone))
                {
                    if (pedido.Cliente.Endereco == null)
                    {
                        return false;
                    }
                }



                if (pedido.Pizzas == null)
                {
                    return false;
                }

                if (pedido.Pizzas.Count > 10)
                {
                    return false;
                }

                foreach (PizzaModel pizza in pedido.Pizzas)
                {
                    if (ValidarPizza(pizza) == false)
                    {
                        return false;

                    }




                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }

        private Boolean ValidarPizza(PizzaModel pizza)
        {
            Boolean retorno = true;

            try
            {
                
                if (pizza.Sabores.Count == 0 || pizza.Sabores.Count > 2)
                {
                    retorno = false;
                }

            }
            catch (Exception ex)
            {
                retorno = false;
            }

            return retorno;
        }

        private List<Sabor> GetSabores()
        {

            List<Sabor> sabores = new List<Sabor>();
            try
            {
                sabores.Add(new Sabor("3Queijos", 50));
                sabores.Add(new Sabor("FrangoComRequeijao", 59.99));
                sabores.Add(new Sabor("Mussarela", 42.50));
                sabores.Add(new Sabor("Calabresa", 42.50));
                sabores.Add(new Sabor("Pepperoni", 55));
                sabores.Add(new Sabor("Portuguesa", 45));
                sabores.Add(new Sabor("Veggie", 59.99));
            }
            catch (Exception ex)
            {
                sabores = null;
            }

            return sabores;
        }

        private Boolean EhCliente(long Fone)
        {
            Boolean retorno = true;

            try
            {
                retorno =  _context.Cliente.Count(e => e.Fone == Fone) > 0;

            }
            catch (Exception ex)
            {
                retorno = false;
            }

            return retorno;
        }

       
        #endregion

    }
}
