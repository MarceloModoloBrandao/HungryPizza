using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using System.Web.Http.Results;
using TesteMarceloModolo.Controllers;
using TesteMarceloModolo.Models;


namespace prjTeste
{
    [TestClass]
    public class UnitTest1
    {
        public class PizzaModelRetorno
        {
            public long preco{get; set; }
        }

        public class PedidoModelRetorno
        {
            public long IdPedido { get; set; }
        }

            [TestMethod]
            public void TestarQtdeSaboresInvalida()
            {
                IRestResponse retPrecoPizza = null;

                PedidoController _pedido = new PedidoController();

                List<Sabor> _sabores = new List<Sabor>();
                _sabores.Add(new Sabor("Mussarela", 42.50));
                _sabores.Add(new Sabor("FrangoComRequeijao", 59.99));
                _sabores.Add(new Sabor("3Queijos", 50));

                retPrecoPizza = RetornarPrecoPizza(_sabores);
                if (retPrecoPizza.StatusCode == HttpStatusCode.BadRequest)
                {
                    Assert.Fail("Qtde sabores invalida");
                }

            }

            [TestMethod]
            public void TestarQtePedidosPizza()
            {
                IRestResponse retPrecoPizza = null;
                IRestResponse retInserirPedido = null;

                PizzaModelRetorno oretornoPizza = null;
                PedidoModelRetorno oretornoPedido = null;

                PedidoController _pedidoController = new PedidoController();

                ClienteModel _cliente = new ClienteModel(999575874);

                List<Sabor> _sabores = new List<Sabor>();
                _sabores.Add(new Sabor("Mussarela", 42.50));
                _sabores.Add(new Sabor("FrangoComRequeijao", 59.99));

                retPrecoPizza = RetornarPrecoPizza(_sabores);
                oretornoPizza = JsonConvert.DeserializeObject<PizzaModelRetorno>(retPrecoPizza.Content);

                List<PizzaModel> _pizzas = new List<PizzaModel>();
                _pizzas.Add(new PizzaModel(_sabores, oretornoPizza.preco));

                PedidoModel _pedido = new PedidoModel(_cliente, _pizzas, 50, 0);
                retInserirPedido = InserirPedido(_pedido);
                oretornoPedido = JsonConvert.DeserializeObject<PedidoModelRetorno>(retInserirPedido.Content);


        }


        #region "Funcoes Privadas"

        private IRestResponse InserirPedido(PedidoModel _pedido)
            {
                IRestResponse retorno = null;
                string SERVICO_CRIAR_PEDIDO = "InserirPedido";
                string URL_SERVICO = "http://localhost:5000/";

                try
                {
                    string DadosBodyJson = JsonConvert.SerializeObject(_pedido, Formatting.Indented);
                    string request = String.Concat(URL_SERVICO, SERVICO_CRIAR_PEDIDO);
                    retorno = ExecutarServico(request, Method.POST, DadosBodyJson);

                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

                return retorno;
            }

        private IRestResponse RetornarPrecoPizza(List<Sabor> _sabores)
            {
                IRestResponse retorno = null;
                string SERVICO_CRIAR_PEDIDO = "RetornarPrecoPizza";
                string URL_SERVICO = "http://localhost:5000/";

                try
                {
                    string DadosBodyJson = JsonConvert.SerializeObject(_sabores, Formatting.Indented);
                    string request = String.Concat(URL_SERVICO, SERVICO_CRIAR_PEDIDO);
                    retorno = ExecutarServico(request, Method.POST, DadosBodyJson);

                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }

                return retorno;

            }

        private IRestResponse ExecutarServico(string p_urlServico, Method p_metodo, string ParamBodyJson = null)
            {
                string res = String.Empty;
                string strDadosErro = String.Empty;

                try
                {
                    var client = new RestClient(p_urlServico);
                    var request = new RestRequest();
                    request.Method = p_metodo;

                    if (ParamBodyJson != null)
                    {
                        request.AddParameter("application/json", ParamBodyJson, ParameterType.RequestBody);
                    }


                    IRestResponse response = client.Execute(request);
                    return response;

                }
                catch (Exception Ex)
                {
                    throw new Exception(Ex.Message);
                }

            }

        #endregion


        }
    }


